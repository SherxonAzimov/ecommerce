// export const API = "http://127.0.0.1:8000/";
export const API = "https://doniyor0277.pythonanywhere.com/";
// export const API = "https://abboskakhkhorov.pythonanywhere.com/";
